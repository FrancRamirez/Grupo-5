#ifndef CLSARCHIVOEMPRESAS_H_INCLUDED
#define CLSARCHIVOEMPRESAS_H_INCLUDED

bool compararRegistros(int num);

class ArchivoEmpresas{
    private:
        char nombre[30];
    public:
        ArchivoEmpresas(const char *n="empresas.dat"){strcpy(nombre,n);}
        void limpiarArchivo();
        void grabarRegistro(Empresa obj);
        void modificarRegistro(Empresa obj, int pos);
        Empresa leerRegistro(int pos);
        void listarArchivo();
        int contarRegistros();
        int buscarRegistro(int num);
};

void ArchivoEmpresas::limpiarArchivo(){
    FILE *p=fopen(nombre, "wb");
    if(p==NULL){return;}
    fclose(p);
}

void ArchivoEmpresas::grabarRegistro(Empresa obj){
    FILE *p=fopen(nombre, "ab");
    if(p==NULL){return;}
    /*if(compararRegistros(obj.getNumero())==true){
        cout<<"NO SE PUDO GRABAR EL ARCHIVO POR: NUMERO DE EMPRESA YA EXISTENTE"<<endl;
        return;
    }
    else*/ fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
}

void ArchivoEmpresas::modificarRegistro(Empresa obj, int pos){
    FILE *p=fopen(nombre, "rb+");
    if(p==NULL){return;}
    fseek(p, pos * sizeof obj, 0);
    fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
}

Empresa ArchivoEmpresas::leerRegistro(int pos){
    Empresa obj;
    obj.setNumero(-1);
    FILE *p=fopen(nombre, "rb");
    if(p==NULL){
        obj.setNumero(-2);
        return obj;
    }
    fseek(p, pos * sizeof obj, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoEmpresas::contarRegistros(){
    FILE *p=fopen(nombre, "rb");
    if(p==NULL){return -1;}
    fseek(p, 0, 2);
    int cantBytes=ftell(p);
    fclose(p);
    return cantBytes/sizeof (Empresa);
}

void ArchivoEmpresas::listarArchivo(){
    int cant=contarRegistros();
    Empresa obj;
    for(int i=0; i<cant; i++){
        obj=leerRegistro(i);
        obj.Mostrar();
        if(obj.getEstado()==true){cout<<endl;}
    }
}

int ArchivoEmpresas::buscarRegistro(int num){
    int cant=contarRegistros();
    Empresa obj;
    for(int i=0; i<cant; i++){
        obj=leerRegistro(i);
        if(num==obj.getNumero()){
            return i;
        }
    }
    return -1;
}

bool compararRegistros(int numero){
    Empresa obj;
    ArchivoEmpresas arcEmp("empresas.dat");

    int cont = arcEmp.contarRegistros();

    for(int i=0;i<cont;i++){
        obj = arcEmp.leerRegistro(i);
        if(numero==obj.getNumero() && obj.getEstado()){
            return true; ///Ya existe un archivo con mismo numero
        }
    }
    return false; ///No existe un archivo con mismo numero
}
#endif // CLSARCHIVOEMPRESAS_H_INCLUDED
