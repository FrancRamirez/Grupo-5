#ifndef MENUCATEGORIAS_H_INCLUDED
#define MENUCATEGORIAS_H_INCLUDED

void menuCategorias(){
    while(true){
        int opc;
        system("cls");
        cout<<"MENU CATEGORIAS"<<endl;
        cout<<"--------------"<<endl;
        cout<<"1 - ALTA CATEGORIA"<<endl;
        cout<<"2 - BAJA LOGICA CATEGORIA"<<endl;
        cout<<"3 - MODIFICAR CATEGORIA"<<endl;
        cout<<"4 - LISTAR CATEGORIA"<<endl;
        cout<<"5 - BUSCAR CATEGORIA POR NUMERO"<<endl;
        cout<<"0 - VOLVER"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaCategoria();
                break;
            case 2:
                bajaLogicaCategorias();
                break;
            case 3:
                modificarRegistroCategoria();
                break;
            case 4:
                listarCategoria();
                break;
            case 5:
                buscarRegistroCategoria();
                break;
            case 0:
                return;
            default:
                cout<<"LA OPCION INGRESADA NO ES CORRECTA"<<endl;
                system("pause");
                break;
        }
        system("pause");
    }
}

#endif // MENUCATEGORIAS_H_INCLUDED
