#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

class Fecha{
private:
    int dia, mes, anio;
public:
    Fecha(int d=1,int m=1,int a=1900){
        dia=d;
        mes=m;
        anio=a;
    }
    void Cargar();
    void Mostrar();
    int getDia(){return dia;}
    int getMes(){return mes;}
    int getAnio(){return anio;}
};

void Fecha::Cargar(){
    cout<<"DIA: ";
    cin>>dia;
    cout<<"MES: ";
    cin>>mes;
    cout<<"ANIO: ";
    cin>>anio;
    cout<<endl;
}

void Fecha::Mostrar(){
    cout<<dia<<"/"<<mes<<"/"<<anio<<endl;
}

class FechaHoy{
private:
    int dia;
    int mes;
    int anio;
public:
    FechaHoy(){
        time_t t = time(0);
        tm* now = localtime(&t);

        dia = now->tm_mday;
        mes = now->tm_mon + 1;
        anio = now->tm_year + 1900;
    }
    int getDia(){return dia;}
    int getMes(){return mes;}
    int getAnio(){return anio;}
};
#endif // FECHA_H_INCLUDED
