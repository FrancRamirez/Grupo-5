#ifndef MENUEMPRESAS_H_INCLUDED
#define MENUEMPRESAS_H_INCLUDED

void menuEmpresas(){
    while(true){
        int opc;
        system("cls");
        cout<<"MENU EMPRESAS"<<endl;
        cout<<"--------------"<<endl;
        cout<<"1 - ALTA EMPRESA"<<endl;
        cout<<"2 - BAJA LOGICA EMPRESA"<<endl;
        cout<<"3 - MODIFICAR CATEGORIA EMPRESA"<<endl;
        cout<<"4 - LISTAR EMPRESAS"<<endl;
        cout<<"5 - BUSCAR EMPRESA POR NUMERO"<<endl;
        cout<<" "<<endl;
        cout<<"0 - VOLVER"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaEmpresa();
                break;
            case 2:
                bajaLogica();
                break;
            case 3:
                modificarRegistro();
                break;
            case 4:
                listarEmpresas();
                break;
            case 5:
                buscarRegistro();
                break;
            case 0:
                return;
            default:
                cout<<"LA OPCION INGRESADA NO ES CORRECTA"<<endl;
                system("pause");
                break;
        }
        system("pause");
    }
}

#endif // MENUEMPRESAS_H_INCLUDED
