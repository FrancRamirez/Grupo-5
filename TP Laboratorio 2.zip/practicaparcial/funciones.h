#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void cargarCadena(char *pal, int tam){
    int i;
    fflush (stdin); ///limpia el buffer de entrada para que la carga se haga sin caracteres que hayan quedado sin usar
    for(i=0; i<tam;i++){
        pal[i]=cin.get();
        if(pal[i]=='\n')break;
    }
    pal[i]='\0';
    fflush(stdin); ///vuelve a limpiar el buffer para eliminar los caracteres sobrantes
}

///EMPRESAS

void listarEmpresas(){
    ArchivoEmpresas arcEmp;
    arcEmp.listarArchivo();
}

void modificarRegistro(){
    ArchivoEmpresas arcEmp("empresas.dat");
    int num;
    cout<<"INGRESE EL NUMERO DE EMPRESA A MODIFICAR: ";
    cin>>num;
    int pos=arcEmp.buscarRegistro(num);
    if(pos<0){
        cout<<"EL NUMERO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    Empresa obj;
    obj = arcEmp.leerRegistro(pos);
    int cat;
    cout<<"INGRESE LA NUEVA CATEGORIA: ";
    cin>>cat;
    obj.setCategoria(cat);
    arcEmp.modificarRegistro(obj, pos);
}

void bajaLogica(){
    ArchivoEmpresas arcEmp;
    int num;
    cout<<"INGRESE EL NUMERO DE EMPRESA A DAR DE BAJA: ";
    cin>>num;
    int pos=arcEmp.buscarRegistro(num);
    if(pos<0){
        cout<<"EL NUMERO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    Empresa obj;
    obj = arcEmp.leerRegistro(pos);
    obj.setEstado(false);
    arcEmp.modificarRegistro(obj, pos);
}

void altaEmpresa(){
    ArchivoEmpresas arcEmp("empresas.dat");
    Empresa obj;
    obj.Cargar();
    int pos=arcEmp.buscarRegistro(obj.getNumero());
    if(pos != -1){
        cout<<"YA EXISTE UNA EMPRESA CON ESE NUMERO EN EL ARCHIVO"<<endl;
        obj.setEstado(false);
    }
    if(obj.getEstado()==true){
        arcEmp.grabarRegistro(obj);
    }else{
        cout<<"NO SE PUDO GRABAR EL REGISTRO"<<endl;
    }
}

void buscarRegistro(){
    int num;
    cout<<"INGRESE EL NUMERO DE LA EMPRESA A BUSCAR: ";
    cin>>num;
    ArchivoEmpresas arcEmp;
    Empresa obj;
    int pos = arcEmp.buscarRegistro(num);
    if(pos<0){
        cout<<"NO EXISTE UNA EMPRESA CON ESE NUMERO EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arcEmp.leerRegistro(pos);
    system("cls");
    obj.Mostrar();
}

///MUNICIPIOS

void listarMunicipios(){
    ArchivoMunicipios arcMun;
    arcMun.listarArchivo();
}

void modificarRegistroMunicipio(){
    ArchivoMunicipios arcMun("municipios.dat");
    int num;
    cout<<"INGRESE EL NUMERO DE EMPRESA A MODIFICAR: ";
    cin>>num;
    int pos=arcMun.buscarRegistro(num);
    if(pos<0){
        cout<<"EL NUMERO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    Municipio obj;
    obj = arcMun.leerRegistro(pos);
    obj.Cargar();
    arcMun.modificarRegistro(obj, pos);
}

void bajaLogicaMunicipios(){
    ArchivoMunicipios arcMun;
    int num;
    cout<<"INGRESE EL NUMERO DE EMPRESA A DAR DE BAJA: ";
    cin>>num;
    int pos=arcMun.buscarRegistro(num);
    if(pos<0){
        cout<<"EL NUMERO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    Municipio obj;
    obj = arcMun.leerRegistro(pos);
    obj.setEstado(false);
    arcMun.modificarRegistro(obj, pos);
}

void altaMunicipios(){
    ArchivoMunicipios arcMun("municipios.dat");
    Municipio obj;
    obj.Cargar();
    int pos=arcMun.buscarRegistro(obj.getNumero());
    if(pos != -1){
        cout<<"YA EXISTE UNA EMPRESA CON ESE NUMERO EN EL ARCHIVO"<<endl;
        obj.setEstado(false);
    }
    if(obj.getEstado()==true){
        arcMun.grabarRegistro(obj);
    }else{
        cout<<"NO SE PUDO GRABAR EL REGISTRO"<<endl;
    }
}

void buscarRegistroMunicipio(){
    int num;
    cout<<"INGRESE EL NUMERO DEL MUNICIPIO A BUSCAR: ";
    cin>>num;
    ArchivoMunicipios arcMun;
    Municipio obj;
    int pos = arcMun.buscarRegistro(num);
    if(pos<0){
        cout<<"NO EXISTE UNA EMPRESA CON ESE NUMERO EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arcMun.leerRegistro(pos);
    system("cls");
    obj.Mostrar();
}

///Categorias

void listarCategoria(){
    ArchivoCategorias arcCat;
    arcCat.listarArchivo();
}

void modificarRegistroCategoria(){
    ArchivoCategorias arcCat("categorias.dat");
    int num;
    cout<<"INGRESE EL NUMERO DE CATEGORIA A MODIFICAR: ";
    cin>>num;
    int pos=arcCat.buscarRegistro(num);
    if(pos<0){
        cout<<"EL NUMERO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    Categoria obj;
    obj = arcCat.leerRegistro(pos);
    obj.Cargar();
    arcCat.modificarRegistro(obj, pos);
}

void bajaLogicaCategorias(){
    ArchivoCategorias arcCat;
    int num;
    cout<<"INGRESE EL NUMERO DE CATEGORIA A DAR DE BAJA: ";
    cin>>num;
    int pos=arcCat.buscarRegistro(num);
    if(pos<0){
        cout<<"EL NUMERO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    Categoria obj;
    obj = arcCat.leerRegistro(pos);
    obj.setEstado(false);
    arcCat.modificarRegistro(obj, pos);
}

void altaCategoria(){
    ArchivoCategorias arcCat("municipios.dat");
    Categoria obj;
    obj.Cargar();
    int pos=arcCat.buscarRegistro(obj.getNumero());
    if(pos != -1){
        cout<<"YA EXISTE UNA CATEGORIA CON ESE NUMERO EN EL ARCHIVO"<<endl;
        obj.setEstado(false);
    }
    if(obj.getEstado()==true){
        arcCat.grabarRegistro(obj);
    }else{
        cout<<"NO SE PUDO GRABAR EL REGISTRO"<<endl;
    }
}

void buscarRegistroCategoria(){
    int num;
    cout<<"INGRESE EL NUMERO DE LA CATEGORIA A BUSCAR: ";
    cin>>num;
    ArchivoCategorias arcCat;
    Categoria obj;
    int pos = arcCat.buscarRegistro(num);
    if(pos<0){
        cout<<"NO EXISTE UNA EMPRESA CON ESE NUMERO EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arcCat.leerRegistro(pos);
    system("cls");
    obj.Mostrar();
}

#endif // FUNCIONES_H_INCLUDED
