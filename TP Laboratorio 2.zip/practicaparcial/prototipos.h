#ifndef PROTOTIPOS_H_INCLUDED
#define PROTOTIPOS_H_INCLUDED

void cargarCadena(char *pal, int tam);
void modificarRegistro();
void bajaLogica();
void altaEmpresa();
void buscarRegistro();

#endif // PROTOTIPOS_H_INCLUDED
