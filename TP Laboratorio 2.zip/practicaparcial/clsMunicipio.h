#ifndef CLSMUNICIPIO_H_INCLUDED
#define CLSMUNICIPIO_H_INCLUDED

class Municipio{
private:
    int numero;
    char nombre[40];
    int seccion;
    int cantidadHabitantes;
    bool estado;
public:
    Municipio(){estado=false;}
    void Cargar(){
        cout<<"NUMERO: ";
        cin>>numero;
        cout<<"NOMBRE :";
        cargarCadena(nombre, 40);
        cout<<"SECCION: ";
        while(true){
        cin>>seccion;
        if(seccion > 0 && seccion < 10){break;}
        else{cout<<"SECCION INVALIDA, INGRESE OTRO: ";}
        }
        cout<<"CANTIDAD DE HABITANTES: ";
        while(true){
        cin>>cantidadHabitantes;
        if(cantidadHabitantes > 0){
            break;
        }
        else{cout<<"INVALIDO, POR FAVOR INGRESE NUEVAMENTE: ";}
        }
        estado=true;
    }
    void Mostrar(){
        if(estado){
        cout<<"NUMERO: "<<numero<<endl;
        cout<<"NOMBRE :"<<nombre<<endl;
        cout<<"SECCION: "<<seccion<<endl;
        cout<<"CANTIDAD DE HABITANTES: "<<cantidadHabitantes<<endl;
        }
    }
    int getNumero(){return numero;}
    const char *getNombre(){return nombre;}
    int getSeccion(){return seccion;}
    int getCantidadHabitantes(){return cantidadHabitantes;}
    bool getEstado(){return estado;}

    void setNumero(int n){numero = n;}
    void setNombre(const char *n){strcpy(nombre, n);}
    void setSeccion(int s){seccion = s;}
    void setCantidadHabitantes(int ch){cantidadHabitantes = ch;}
    void setEstado(bool e){estado = e;}
};

#endif // CLSMUNICIPIO_H_INCLUDED
