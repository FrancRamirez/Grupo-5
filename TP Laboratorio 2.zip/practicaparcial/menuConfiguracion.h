#ifndef MENUCONFIGURACION_H_INCLUDED
#define MENUCONFIGURACION_H_INCLUDED

void menuConfiguracion(){

void backupEmpresas();
void restaurarEmpresas();
void backupMunicipios();
void restaurarMunicipios();
void restablecerTodo();

while(true){
        int opc;
        system("cls");
        cout<<"CONFIGURACION"<<endl;
        cout<<"--------------"<<endl;
        cout<<"1 - BACK UP EMPRESAS"<<endl;
        cout<<"2 - BACK UP MUNICIPIOS"<<endl;
        cout<<"3 - RESTABLECER EMPRESAS"<<endl;
        cout<<"4 - RESTABLECER MUNICIPIOS"<<endl;
        cout<<"5 - RESTABLECER TODO"<<endl;
        cout<<" "<<endl;
        cout<<"0 - VOLVER"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                backupEmpresas();
                break;
            case 2:
                backupMunicipios();
                break;
            case 3:
                restaurarEmpresas();
                break;
            case 4:
                restaurarMunicipios();
                break;
            case 5:
                restablecerTodo();
                break;
            case 0:
                return;
            default:
                cout<<"LA OPCION INGRESADA NO ES CORRECTA"<<endl;
                system("pause");
                break;
        }
        system("pause");
    }
}

void backupEmpresas(){
    ArchivoEmpresas arcEmp;
    ArchivoEmpresas bkpEmp("empresas.bkp");
    Empresa obj;
    ///arcEmp.limpiarArchivo();
    int cant=arcEmp.contarRegistros();
    for(int i=0;i<cant;i++){
        obj=arcEmp.leerRegistro(i);
        bkpEmp.grabarRegistro(obj);
    }
}

void backupMunicipios(){
    ArchivoMunicipios arcMun;
    ArchivoMunicipios bkpMun("municipios.bkp");
    Municipio obj;
    ///arcMun.limpiarArchivo();
    int cant=arcMun.contarRegistros();
    for(int i=0;i<cant;i++){
        obj=arcMun.leerRegistro(i);
        bkpMun.grabarRegistro(obj);
    }
}

void restaurarEmpresas(){
    ArchivoEmpresas arcEmp;
    ArchivoEmpresas bkpEmp("empresas.bkp");
    Empresa obj;
    arcEmp.limpiarArchivo();
    int cant=arcEmp.contarRegistros();
    for(int i=0;i<cant;i++){
        obj=bkpEmp.leerRegistro(i);
        arcEmp.grabarRegistro(obj);
    }
}

void restaurarMunicipios(){
    ArchivoMunicipios arcMun;
    ArchivoMunicipios bkpMun("municipios.bkp");
    Municipio obj;
    arcMun.limpiarArchivo();
    int cant=arcMun.contarRegistros();
    for(int i=0;i<cant;i++){
        obj=bkpMun.leerRegistro(i);
        arcMun.grabarRegistro(obj);
    }
}

void restablecerTodo(){
    ArchivoEmpresas arcEmp("empresas.dat");
    ArchivoMunicipios arcMun("municipios.dat");
    arcEmp.limpiarArchivo();
    arcMun.limpiarArchivo();
}
#endif // MENUCONFIGURACION_H_INCLUDED
