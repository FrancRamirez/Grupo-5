#include <iostream>
#include <cstring>
#include <ctime>

using namespace std;

#include "Fecha.h"
#include "prototipos.h"
#include "clsEmpresa.h"
#include "clsArchivoEmpresas.h"
#include "clsMunicipio.h"
#include "clsArchivoMunicipio.h"
#include "clsCategorias.h"
#include "clsArchivoCategoria.h"
#include "funciones.h"
#include "menuMunicipios.h"
#include "menuEmpresas.h"
#include "reportes.h"
#include "menuConfiguracion.h"
#include "menuCategorias.h"


int main(){
    while(true){
        int opc;
        system("cls");
        cout<<"MENU PRINCIPAL"<<endl;
        cout<<"--------------"<<endl;
          cout<<"1 - MENU EMPRESAS"<<endl;
          cout<<"2 - MENU MUNICIPIOS"<<endl;
          cout<<"3 - REPORTES"<<endl;
          cout<<"4 - CONFIGURACION"<<endl;
        cout<<"0 - SALIR"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                menuEmpresas();
                break;
            case 2:
                menuMunicipios();
                break;
            case 3:
                MenuReportes();
                break;
            case 4:
                menuConfiguracion();
                break;
            case 5:
                ///buscarRegistro();
                break;
            case 0:
                return 0;
            default:
                cout<<"LA OPCION INGRESADA NO ES CORRECTA"<<endl;
                system("pause");
                break;
        }
    }
    return 0;

}
