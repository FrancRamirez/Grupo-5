#ifndef CLSEMPRESA_H_INCLUDED
#define CLSEMPRESA_H_INCLUDED

class Empresa{
    private:
        int numero;
        char nombre[30];
        int cantidadEmpleados;
        int categoria;
        int numeroMunicipio;
        Fecha fecha;
        float facturacionAnual;
        bool estado;
    public:
        Empresa(){estado=false;}
        void setNumero(int n){numero = n;}
        void setCategoria(int c){categoria = c;}
        void setFecha(Fecha f){f.Cargar();}
        void setFacturacionAnual(float fa){facturacionAnual = fa;}
        void setEstado(bool e){estado = e;}

        int getNumero(){return numero;}
        int getCantidadEmpleados(){return cantidadEmpleados;}
        int getNumeroMunicipio(){return numeroMunicipio;}
        int getCategoria(){return categoria;}
        Fecha getFecha(){return fecha;}
        float getFacturacionAnual(){return facturacionAnual;}
        bool getEstado(){return estado;}

        void Cargar();
        void Mostrar();
};

void Empresa::Cargar(){
    Fecha obj;
    FechaHoy hoy;
    bool valida = false;
    cout<<"NUMERO: ";
    cin>>numero;
    cout<<"NOMBRE: ";
    cargarCadena(nombre,29);
    cout<<"CANTIDAD DE EMPLEADOS: ";
    while(true){
    cin>>cantidadEmpleados;
    if(cantidadEmpleados<0){
        cout<<"NO ES VALIDO, INGRESE OTRO: ";
        }
    else{break;}
    }
    cout<<"CATEGORIA: ";
    while(true){
    cin>>categoria;
    if(categoria<1 || categoria>80){
        cout<<"CATEGORIA INGRESADA INCORRECTA, INGRESELO NUEVAMENTE: "<<endl;
    }else{break;}
    }
    cout<<"NUMERO DE MUNICIPIO: ";
    while(true){
    cin>>numeroMunicipio;
    if(numeroMunicipio<1 || numeroMunicipio>135){
        cout<<"CATEGORIA INGRESADA INCORRECTA, INGRESELO NUEVAMENTE: "<<endl;
    }else{break;}
    }
    cout<<"FECHA: "<<endl;
    while(valida==false){
        obj.Cargar();
        if(obj.getAnio() <= hoy.getAnio()){
            valida=true;
        }
        else if(obj.getAnio()==hoy.getAnio() && obj.getMes() <= hoy.getMes()){
            valida=true;
        }
        else if(obj.getAnio()==hoy.getAnio() && obj.getMes() == hoy.getMes() && obj.getDia() <= hoy.getDia()){
            valida=true;
        }
        if(valida==false){
            cout<<"La fecha ingresada no es valida"<<endl;
        }
    }
    cout<<"FACTURACION ANUAK: ";
    cin>>facturacionAnual;
    estado=true;
}

void Empresa::Mostrar(){
    if(estado==true){
        cout<<"NUMERO: "<<numero<<endl;
        cout<<"NOMBRE: "<<nombre<<endl;
        cout<<"CANTIDAD DE EMPLEADOS: "<<cantidadEmpleados<<endl;
        cout<<"CATEGORIA: "<<categoria<<endl;
        cout<<"NUMERO DE MUNICIPIO: "<<numeroMunicipio<<endl;
        fecha.Mostrar();
        cout<<"FACTURACION ANUAL: "<<facturacionAnual<<endl;
    }
}

#endif // CLSEMPRESA_H_INCLUDED
