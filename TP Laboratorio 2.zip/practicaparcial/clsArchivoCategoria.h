#ifndef CLSARCHIVOCATEGORIA_H_INCLUDED
#define CLSARCHIVOCATEGORIA_H_INCLUDED

class ArchivoCategorias{
private:
    char nombre[40];
public:
    ArchivoCategorias(const char *n = "categorias.dat"){strcpy(nombre, n);}
    void limpiarArchivo();
    void grabarRegistro(Categoria obj);
    void modificarRegistro(Categoria obj, int pos);
    Categoria leerRegistro(int pos);
    void listarArchivo();
    int contarRegistros();
    int buscarRegistro(int num);
};

void ArchivoCategorias::limpiarArchivo(){
    FILE *p=fopen(nombre, "wb");
    if(p==NULL){return;}
    fclose(p);
}
void ArchivoCategorias::grabarRegistro(Categoria obj){
    FILE *p=fopen(nombre, "ab");
    if(p==NULL){return;}
    fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
}
void ArchivoCategorias::modificarRegistro(Categoria obj, int pos){
    FILE *p=fopen(nombre, "rb+");
    if(p==NULL){return;}
    fseek(p, pos * sizeof obj, 0);
    fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
}
Categoria ArchivoCategorias::leerRegistro(int pos){
    Categoria obj;
    obj.setNumero(-1);
    FILE *p=fopen(nombre, "rb");
    if(p==NULL){
        obj.setNumero(-2);
        return obj;
        }
    fseek(p, pos * sizeof obj, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}
void ArchivoCategorias::listarArchivo(){
    int cant=contarRegistros();
    Categoria obj;
    for(int i=0; i<cant; i++){
        obj=leerRegistro(i);
        obj.Mostrar();
        if(obj.getEstado()==true){cout<<endl;}
    }
}
int ArchivoCategorias::contarRegistros(){
    FILE *p=fopen(nombre, "rb");
    if(p==NULL){return -1;}
    fseek(p, 0, 2);
    int cantBytes=ftell(p);
    fclose(p);
    return cantBytes/sizeof (Categoria);
}
int ArchivoCategorias::buscarRegistro(int num){
    int cant=contarRegistros();
    Categoria obj;
    for(int i=0; i<cant; i++){
        obj=leerRegistro(i);
        if(num==obj.getNumero()){
            return i;
        }
    }
    return -1;
}

#endif // CLSARCHIVOCATEGORIA_H_INCLUDED
