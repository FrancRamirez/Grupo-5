#ifndef MENUMUNICIPIOS_H_INCLUDED
#define MENUMUNICIPIOS_H_INCLUDED

void menuMunicipios(){
    while(true){
        int opc;
        system("cls");
        cout<<"MENU MUNICIPIO"<<endl;
        cout<<"--------------"<<endl;
        cout<<"1 - ALTA MUNICIPIO"<<endl;
        cout<<"2 - BAJA LOGICA MUNICIPIO"<<endl;
        cout<<"3 - MODIFICAR MUNICIPIO"<<endl;
        cout<<"4 - LISTAR MUNICIPIO"<<endl;
        cout<<"5 - BUSCAR MUNICIPIO POR NUMERO"<<endl;
        cout<<"0 - VOLVER"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaMunicipios();
                break;
            case 2:
                bajaLogicaMunicipios();
                break;
            case 3:
                modificarRegistroMunicipio();
                break;
            case 4:
                listarMunicipios();
                break;
            case 5:
                buscarRegistroMunicipio();
                break;
            case 0:
                return;
            default:
                cout<<"LA OPCION INGRESADA NO ES CORRECTA"<<endl;
                system("pause");
                break;
        }
        system("pause");
    }
}

#endif // MENUMUNICIPIOS_H_INCLUDED
