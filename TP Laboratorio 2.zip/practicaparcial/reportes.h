#ifndef REPORTES_H_INCLUDED
#define REPORTES_H_INCLUDED

void punto1();
void punto2();
void punto3();
void punto4();
void punto5();
void punto6();
void punto7();
void punto8();

void grabarNuevoReegistro(Empresa obj){
    FILE *p=fopen("EmpresaMunicipio300000.dat","ab");
    if(p==NULL){return;}
    fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
}

void funcionMunicipio(Empresa emp, int num){
    Municipio obj;
    ArchivoMunicipios arcMun("municipios.dat");

    int cant = arcMun.contarRegistros();

    for(int i=0;i<cant;i++){
        obj = arcMun.leerRegistro(i);
        if(num==obj.getNumero() && obj.getCantidadHabitantes() > 300000 && obj.getEstado()){
            grabarNuevoReegistro(emp);
        }
    }
}

void listarMunicipiosPorEmpresa(int num){
    Municipio obj;
    ArchivoMunicipios arcMun("municipios.dat");

    int cant = arcMun.contarRegistros();

    for(int i=0;i<cant;i++){
        obj = arcMun.leerRegistro(i);
        if(num==obj.getNumero() && obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}




void MenuReportes(){
     while(true){
        int opc;
        system("cls");
        cout<<"MENU REPORTES"<<endl;
        cout<<"--------------"<<endl;
        cout<<"1 - PUNTO 1"<<endl;
        cout<<"2 - PUNTO 2"<<endl;
        cout<<"3 - PUNTO 3"<<endl;
        cout<<"4 - PUNTO 4"<<endl;
        cout<<"5 - PUNTO 5"<<endl;
        cout<<"6 - PUNTO 6"<<endl;
        cout<<"7 - PUNTO 7"<<endl;
        cout<<"8 - PUNTO 8"<<endl;
        cout<<" "<<endl;
        cout<<"0 - VOLVER"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                ///punto1();
                break;
            case 2:
                ///punto2();
                break;
            case 3:
                ///punto3();
                break;
            case 4:
                ///punto4();
                break;
            case 5:
                ///punto5();
                break;
            case 6:
                ///punto6();
                break;
            case 7:
                ///punto7();
                break;
            case 8:
                ///punto8();
                break;
            case 0:
                return;
            default:
                cout<<"LA OPCION INGRESADA NO ES CORRECTA"<<endl;
                system("pause");
                break;
        }
        system("pause");
    }

}

void punto1(){
    int cat;
    cout<<"INGRESE UNA CATEGORIA: ";
    cin>>cat;
    Empresa obj;
    ArchivoEmpresas arcEmp;
    int cant=arcEmp.contarRegistros();
    for(int i=0; i<cant; i++){
        obj = arcEmp.leerRegistro(i);
        if(obj.getCategoria()==cat && obj.getEstado()){
            obj.Mostrar();
        }
    }
}

void punto2(){
    ArchivoEmpresas arcEmp;
    Empresa obj;
    int cant = arcEmp.contarRegistros();
    for(int i=0;i<cant;i++){
        obj = arcEmp.leerRegistro(i);
        if(obj.getCantidadEmpleados()>50 && obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}

void contarEmpresasPorMunicipio(int *vec){
    ArchivoEmpresas arcEmp;
    Empresa obj;
    int cant = arcEmp.contarRegistros();
    for(int i=0;i<cant;i++){
        obj = arcEmp.leerRegistro(i);
        if(obj.getEstado()){
        vec[obj.getNumeroMunicipio()-1]++;
        }
    }
}

void punto3(){
    int vec[135]={};
    contarEmpresasPorMunicipio(vec);
    int cont = 0;
    for(int i=0;i<135;i++){
        if(vec[i]==0){
            cont++;
        }
    }
    cout<<"LA CANTIDAD DE MUNICIPIOS SIN EMPRESAS ES: "<<cont<<endl;
}

void punto4(){
    int vec[135]={};
    contarEmpresasPorMunicipio(vec);
    for(int i=0;i<135;i++){
        if(vec[i]>5){
            cout<<"EL MUNICIPIO "<<i+1<<" CONTIENE "<<vec[i]<<" EMPRESAS"<<endl;
        }
    }
}

void punto5(){
    int cat[80]={};
    Empresa obj;
    ArchivoEmpresas arcEmp;
    int cant=arcEmp.contarRegistros();
    for(int i=0;i<cant;i++){
        obj=arcEmp.leerRegistro(i);
        if(obj.getEstado()){
            cat[obj.getCategoria()-1]++;
        }
    }

    int maximo = cat[0];
    int numCat = 0;

    for(int i=1;i<80;i++){
        if(cat[i]>maximo){
            maximo=cat[i];
            numCat = i;
        }
    }
    cout<<"LA CATEGORIA CON MAYOR CANTIDAD DE EMPRESAS ES: "<<numCat+1<<endl<<" CON LA CANTIDAD DE: "<<maximo<<endl;
}

void punto6(){
    Empresa obj;
    ArchivoEmpresas arcEmp("empresas.dat");

    int cant = arcEmp.contarRegistros();

    for(int i=0;i<cant;i++){
        obj = arcEmp.leerRegistro(i);
        funcionMunicipio(obj, obj.getNumeroMunicipio());
    }
}

void punto7(){
    Empresa obj;
    ArchivoEmpresas arcEmp("empresas.dat");

    int Categoria = 0;
    cout<<"INGRESE CATEGORIA: ";
    cin>>Categoria;
    int cant = arcEmp.contarRegistros();

    for(int i=0;i<cant;i++){
        obj = arcEmp.leerRegistro(i);
        if(obj.getCategoria()!=Categoria && obj.getEstado()){
            listarMunicipiosPorEmpresa(obj.getNumeroMunicipio());
        }
    }
}

void punto8(){

}

#endif // REPORTES_H_INCLUDED
