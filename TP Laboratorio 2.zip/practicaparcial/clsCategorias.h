#ifndef CLSCATEGORIAS_H_INCLUDED
#define CLSCATEGORIAS_H_INCLUDED

class Categoria{
    private:
        int numero;
        char nombre[30];
        bool estado;
    public:
        Categoria(){estado=false;}
        void setNumero(int n){numero = n;}
        void setNombre(const char *n){strcpy(nombre, n);}
        void setEstado(bool e){estado = e;}
        int getNumero(){return numero;}
        bool getEstado(){return estado;}
        void Cargar();
        void Mostrar();
};

void Categoria::Cargar(){
    cout<<"NUMERO: ";
    cin>>numero;
    if(numero<1){
        return;
    }
    cout<<"NOMBRE: ";
    cargarCadena(nombre,29);
    estado=true;
}

void Categoria::Mostrar(){
    if(estado==true){
        cout<<"NUMERO: "<<numero<<endl;
        cout<<"NOMBRE: "<<nombre<<endl;
    }
}

#endif // CLSCATEGORIAS_H_INCLUDED
